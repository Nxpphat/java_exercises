package appGUI;

import org.mindrot.jbcrypt.BCrypt;
import javax.xml.bind.*;
import java.io.*;
import java.util.*;

public class UserManager {
    private static final String FILE_NAME = "users.xml";
    private List<User> users;

    public UserManager() {
        users = loadUsers();
    }

    // Mã hóa mật khẩu bằng bcrypt
    public String hashPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt());
    }

    // Kiểm tra mật khẩu
    public boolean checkPassword(String password, String hashedPassword) {
        return BCrypt.checkpw(password, hashedPassword);
    }

    // Đăng ký người dùng
    public boolean registerUser(String username, String password) {
        for (User u : users) {
            if (u.getUsername().equals(username)) {
                return false; // Tên người dùng đã tồn tại
            }
        }
        users.add(new User(username, hashPassword(password)));
        saveUsers();
        return true;
    }

    // Đăng nhập người dùng
    public boolean loginUser(String username, String password) {
        for (User u : users) {
            if (u.getUsername().equals(username) && checkPassword(password, u.getHashedPassword())) {
                return true;
            }
        }
        return false;
    }

    // Lưu danh sách người dùng vào file XML
    public void saveUsers() {
        try {
            JAXBContext context = JAXBContext.newInstance(UserList.class);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(new UserList(users), new File(FILE_NAME));
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }

    // Tải danh sách người dùng từ file XML
    public List<User> loadUsers() {
        try {
            File file = new File(FILE_NAME);
            if (!file.exists()) return new ArrayList<>();
            JAXBContext context = JAXBContext.newInstance(UserList.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            return ((UserList) unmarshaller.unmarshal(file)).getUsers();
        } catch (JAXBException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
}

