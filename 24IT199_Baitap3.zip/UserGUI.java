package appGUI;

import javax.swing.*;
import java.awt.event.*;

public class UserGUI {
    private UserManager userManager = new UserManager();

    public UserGUI() {
        JFrame frame = new JFrame("Quản lý người dùng");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        frame.add(panel);
        placeComponents(panel);
        frame.setVisible(true);
    }

    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel userLabel = new JLabel("Tên người dùng:");
        userLabel.setBounds(10, 20, 120, 25);
        panel.add(userLabel);

        JTextField userText = new JTextField(20);
        userText.setBounds(150, 20, 200, 25);
        panel.add(userText);

        JLabel passwordLabel = new JLabel("Mật khẩu:");
        passwordLabel.setBounds(10, 50, 120, 25);
        panel.add(passwordLabel);

        JPasswordField passwordText = new JPasswordField(20);
        passwordText.setBounds(150, 50, 200, 25);
        panel.add(passwordText);

        JButton registerButton = new JButton("Đăng ký");
        registerButton.setBounds(10, 90, 150, 25);
        panel.add(registerButton);

        JButton loginButton = new JButton("Đăng nhập");
        loginButton.setBounds(200, 90, 150, 25);
        panel.add(loginButton);

        JLabel messageLabel = new JLabel("");
        messageLabel.setBounds(10, 130, 350, 25);
        panel.add(messageLabel);

        // Xử lý đăng ký
        registerButton.addActionListener(e -> {
            String username = userText.getText();
            String password = new String(passwordText.getPassword());
            if (userManager.registerUser(username, password)) {
                messageLabel.setText("Đăng ký thành công!");
            } else {
                messageLabel.setText("Tên người dùng đã tồn tại!");
            }
        });

        // Xử lý đăng nhập
        loginButton.addActionListener(e -> {
            String username = userText.getText();
            String password = new String(passwordText.getPassword());
            if (userManager.loginUser(username, password)) {
                messageLabel.setText("Đăng nhập thành công!");
            } else {
                messageLabel.setText("Sai tên đăng nhập hoặc mật khẩu!");
            }
        });
    }

    public static void main(String[] args) {
        new UserGUI();
    }
}
