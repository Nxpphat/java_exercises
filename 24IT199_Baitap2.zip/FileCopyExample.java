package Exercises2;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopyExample {
    public static void main(String[] args) {
        String sourceFile = "input.txt";  // Tên file nguồn
        String destFile = "output.txt";   // Tên file đích

        try (FileInputStream fis = new FileInputStream(sourceFile);
             FileOutputStream fos = new FileOutputStream(destFile)) {

            int byteData;
            while ((byteData = fis.read()) != -1) {
                fos.write(byteData);
            }
            System.out.println("Sao chép tệp thành công!");

        } catch (IOException e) {
            System.err.println("Lỗi khi đọc hoặc ghi tệp: " + e.getMessage());
        }
    }
}

