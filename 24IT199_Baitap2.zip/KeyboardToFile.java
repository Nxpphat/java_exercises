package Exercises2;

import java.io.*;

public class KeyboardToFile {
    public static void main(String[] args) {
        String fileName = "output.txt"; // Tên file để lưu dữ liệu

        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
             BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {

            System.out.println("Nhập dữ liệu (gõ 'exit' để kết thúc):");

            String line;
            while (!(line = br.readLine()).equalsIgnoreCase("exit")) {
                bw.write(line);
                bw.newLine(); // Xuống dòng trong file
            }

            System.out.println("Dữ liệu đã được lưu vào " + fileName);

        } catch (IOException e) {
            System.err.println("Lỗi khi xử lý file: " + e.getMessage());
        }
    }
}
