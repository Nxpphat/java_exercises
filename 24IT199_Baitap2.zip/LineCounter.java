package Exercises2;

import java.io.*;

public class LineCounter {
    public static void main(String[] args) {
        String fileName = "input.txt"; // Đặt tên file cần đọc

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            int lineCount = 0;
            while (br.readLine() != null) {
                lineCount++;
            }
            System.out.println("Số dòng trong file: " + lineCount);
        } catch (IOException e) {
            System.err.println("Lỗi khi đọc file: " + e.getMessage());
        }
    }
}

