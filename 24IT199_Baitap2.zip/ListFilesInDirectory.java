package Exercises2;

import java.io.File;

public class ListFilesInDirectory {
    public static void main(String[] args) {
        String directoryPath = "C:\\Users\\Public\\Documents"; // Đường dẫn thư mục cần liệt kê

        File directory = new File(directoryPath);

        // Kiểm tra xem đường dẫn có phải là một thư mục không
        if (directory.isDirectory()) {
            File[] fileList = directory.listFiles(); // Lấy danh sách các tệp và thư mục con

            if (fileList != null && fileList.length > 0) {
                System.out.println("Danh sách tệp trong thư mục: " + directoryPath);
                for (File file : fileList) {
                    System.out.println((file.isDirectory() ? "[Thư mục] " : "[Tệp] ") + file.getName());
                }
            } else {
                System.out.println("Thư mục trống.");
            }
        } else {
            System.out.println("Đường dẫn không phải là một thư mục hợp lệ.");
        }
    }
}
