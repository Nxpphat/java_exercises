package Exercises2;

import java.io.*;

public class IntegerFileHandler {
    public static void main(String[] args) {
        String fileName = "numbers.dat"; // Tên file nhị phân lưu số nguyên

        // Ghi danh sách số nguyên vào file
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(fileName))) {
            int[] numbers = {10, 20, 30, 40, 50}; // Danh sách số cần ghi
            for (int num : numbers) {
                dos.writeInt(num); // Ghi từng số nguyên vào file
            }
            System.out.println("Ghi danh sách số nguyên vào file thành công!");
        } catch (IOException e) {
            System.err.println("Lỗi khi ghi file: " + e.getMessage());
        }

        // Đọc lại danh sách số nguyên từ file
        try (DataInputStream dis = new DataInputStream(new FileInputStream(fileName))) {
            System.out.println("Danh sách số nguyên đọc từ file:");
            while (dis.available() > 0) { // Kiểm tra còn dữ liệu để đọc
                System.out.println(dis.readInt()); // Đọc từng số nguyên
            }
        } catch (IOException e) {
            System.err.println("Lỗi khi đọc file: " + e.getMessage());
        }
    }
}
